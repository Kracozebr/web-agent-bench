---
name: Web3 Agent Bench
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#464555'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#004c76'
  on-tertiary: '#ffffff'
  tertiary-container: '#00659a'
  on-tertiary-container: '#bedfff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#cce5ff'
  tertiary-fixed-dim: '#93ccff'
  on-tertiary-fixed: '#001d31'
  on-tertiary-fixed-variant: '#004b73'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Geist
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Geist
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Geist
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.005em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: -0.01em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system targets blockchain engineers, AI agent architects, and protocol security auditors who demand absolute clarity, precision, and verification rigor. The interface avoids speculative crypto maximalism and decorative sci-fi tropes; instead, it establishes trust through surgical information density, verifiable metrics, and high-performance developer ergonomics.

The visual style blends modern technical minimalism with high-density data utility—heavily influenced by developer-first platforms like Linear, Stripe, and Cloudflare. Crisp structural frames, sharp structural discipline, monospaced computational telemetry, and disciplined neutral surfaces allow benchmark percentiles, runtime logs, and smart contract execution traces to take absolute priority.

## Colors

The palette is engineered around an ultra-clean base with surgical accents to ensure immediate scanning across large data matrices and verification logs.

- **Primary (`#4F46E5` - Deep Indigo):** Reserved for intentional primary actions, active navigation states, selected table rows, and cryptographic verification badges.
- **Secondary (`#0F172A` - Slate 900):** High-contrast structural slate used for primary headings, metric keys, code block surfaces, and primary terminal buttons.
- **Tertiary (`#0284C7` - Sky 600):** Dedicated to network routing indicators, RPC state switches, and active pipeline triggers.
- **Neutral (`#64748B` - Slate 500):** Balanced utilitarian neutral scale. The foundation canvas sits at `#F8FAFC` (Slate 50), elevated container surfaces at `#FFFFFF`, and structural hairline borders at `#E2E8F0` (Slate 200).
- **Semantics:** 
  - Emerald (`#059669` / `#ECFDF5`): Agent benchmark pass, consensus reached, verified zk-proof.
  - Amber (`#D97706` / `#FFFBEB`): Gas spike anomaly, latency threshold warning, non-deterministic execution.
  - Rose (`#E11D48` / `#FFF1F2`): Execution revert, adversarial vulnerability, invariant failure.

## Typography

The typographic hierarchy couples **Geist** for structural interface copy with **JetBrains Mono** for all machine-readable output: transaction hashes, byte sizes, gas computations, deterministic score tags, and latency metrics.

- Headers are set tight with slight negative tracking (`-0.02em` to `-0.03em`) to anchor technical weight without overwhelming horizontal space.
- Monospaced labels feature slightly raised tracking for readability at small point sizes (11px–13px) in dense data grids.
- Tabular figures (`tnum`) must be enforced across all numeric and metric outputs in tables to prevent visual jitter during real-time benchmark streaming.

## Layout & Spacing

The layout is structured on a strict 12-column responsive fluid grid capped at a max-width of 1440px for wide screens. A 4px baseline sub-grid drives all internal component padding, input heights, and telemetry stacks.

- **Desktop (≥1280px):** 12-column grid, 1.5rem gutters, 3rem canvas margin. Multi-column data layouts, inline terminal drawers, and side-by-side agent comparison matrices.
- **Tablet (768px – 1279px):** 8-column grid, 1.25rem gutters, 2rem canvas margin. Side panels collapse into top-level tabs or slide-over inspector sheets.
- **Mobile (<768px):** 4-column grid, 1rem gutters, 1rem canvas margin. Dense data tables switch to stacked key-value verification cards with horizontal overflow wrappers for code outputs.

## Elevation & Depth

This design system avoids heavy, blurred drop shadows. Depth is achieved primarily through crisp tonal layering and hairline structural borders:

- **Layer 0 (Canvas):** `#F8FAFC` base surface for page background.
- **Layer 1 (Card/Containers):** `#FFFFFF` pure white surfaces, framed by a 1px solid `#E2E8F0` border.
- **Layer 2 (Elevated Flyouts/Dropdowns):** `#FFFFFF` paired with an ultra-subtle ambient shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.05), 0 1px 2px -1px rgba(15, 23, 42, 0.05)` and a 1px solid `#CBD5E1` border.
- **Layer 3 (Modals/Overlays):** `#FFFFFF` with a directional elevation shadow: `0 10px 15px -3px rgba(15, 23, 42, 0.08), 0 4px 6px -4px rgba(15, 23, 42, 0.04)` over a `#0F172A` backdrop at 30% opacity.
- **Layer 4 (Terminal/Log Viewer):** Inverted `#0F172A` surface with 1px `#1E293B` inner borders, creating visual contrast for runtime outputs.

## Shapes

The design system uses a restrained corner radius (Level 1: Soft). Base interactive components utilize a tight `0.25rem` (4px) corner radius, preserving a sharp, tool-like precision. Container cards, modal shells, and multi-metric dashboards scale to `0.5rem` (8px). 

Circular elements are strictly reserved for agent avatar placeholders, consensus status pips, and round icon buttons. Highly rounded or pill-shaped containers are forbidden for cards and standard buttons to maintain technical authority.

## Components

### Buttons
- **Primary:** `#4F46E5` fill, `#FFFFFF` text, `4px` radius. Hover: `#4338CA`. Active: `#3730A3`. Focused with a 2px outline offset by 2px in `#A5B4FC`.
- **Secondary:** `#FFFFFF` fill, `#0F172A` text, 1px `#E2E8F0` border. Hover: `#F8FAFC` fill, border `#CBD5E1`.
- **Tertiary/Ghost:** Transparent fill, `#64748B` text. Hover: `#F1F5F9` fill, `#0F172A` text.
- **Terminal Action:** `#0F172A` background, `#F8FAFC` text, 1px `#334155` border, `JetBrains Mono` label.

### Data Tables & Benchmark Grids
- **Header:** `#F8FAFC` background, 1px bottom border in `#E2E8F0`, `JetBrains Mono` 11px uppercase labels in `#64748B`.
- **Row:** Minimum 44px height for high density. `#FFFFFF` background, subtle transition to `#F8FAFC` on hover. Selected row features a 2px vertical left indicator in `#4F46E5` with `#EEF2FF` tint.
- **Cells:** Numeric and cryptographic values set in `JetBrains Mono` with tabular numbers.

### Chips & Status Tags
- **Monospace Score Chips:** Outlined badges with 1px borders, `JetBrains Mono` 12px text. Example: Score `98.4/100` uses `#ECFDF5` background, `#059669` border, and `#065F46` text.
- **Network & Verification Tags:** Height 20px, 4px radius, inline-flex with a 6px semantic indicator dot. E.g., `ZK-VERIFIED`, `ETH-SEPOLIA`, `ARBITRUM-ONE`.

### Input Fields & Selects
- Height 36px, `0.25rem` radius, `#FFFFFF` fill, 1px `#CBD5E1` border.
- Typography: Geist 14px for natural text, `JetBrains Mono` 13px for contract addresses, private RPC endpoints, and parameters.
- Focus: 1px `#4F46E5` border with `0 0 0 1px #4F46E5` ring.

### Checkboxes & Radios
- Size 16px × 16px, `0.25rem` radius for checkboxes, full circle for radios.
- Unchecked: `#FFFFFF` fill, 1px `#CBD5E1` border.
- Checked: `#4F46E5` fill with white glyph checkmark or center pip.

### Cards & Container Panels
- `#FFFFFF` background, 1px solid `#E2E8F0` border, `0.5rem` radius. Header separated by a 1px horizontal `#E2E8F0` divider line. Generous padding (`1.5rem`) balancing tight component internals.